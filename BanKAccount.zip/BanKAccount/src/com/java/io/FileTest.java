package com.java.io;




import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;


public class FileTest {
	public static void main(String[] args) { //king.txt and queen.txt 
		StoryTeller story1 = new StoryTeller("C:\\Users\\SBT29\\eclipse-workspace/prince.txt");
		story1.openFile();
		story1.readFile();
		story1.closeFile();
		
		StoryTeller story2 = new StoryTeller("C:\\Users\\SBT29\\eclipse-workspaceking.txt");
		story2.openFile();
		story2.readFile();
		story2.closeFile();
		
		StoryTeller story3 = new StoryTeller("C:\\Users\\SBT29\\eclipse-workspacequeen.txt");
		story3.openFile();
		story3.readFile();
		story3.closeFile();
		
		
	}
}
/* For reading multiple  files make a class and use the concept of oop,so that we dont 
 * have to call it again and again
 * 
 * */

