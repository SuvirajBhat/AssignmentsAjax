package com.java.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileTest3 {
	public static void main(String[] args) {
		try {
			FileInputStream fin = new FileInputStream("C:\\Users\\SBT29\\eclipse-workspace\\queen.txt");
			System.out.println("File is ready...");
		
			byte b = (byte) fin.read();
			
			while(b!=-1) {
				System.out.print((char)b);
				b = (byte) fin.read();
			}
			fin.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}

