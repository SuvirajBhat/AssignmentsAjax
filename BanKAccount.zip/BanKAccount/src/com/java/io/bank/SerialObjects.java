package com.java.io.bank;

public class SerialObjects {

}
