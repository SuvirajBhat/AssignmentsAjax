package com.suvi;

public class Tester {
public static void main(String[] args) {
	Animals dog=new Animals();
	dog.setVoice("bark");
	Animals cat=new Animals();
	cat.setWeight(7);
	dog.setWeight(60);;
	System.out.println(dog.getVoice());
	System.out.println(dog.getWeight());//not a good practice, 
	System.out.println(dog.getWeight());
}
}
