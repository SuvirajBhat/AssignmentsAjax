package com.java.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.java.model.Player;

public class PlayerDaoo {static HashMap<String, Player> PlayersMap = new HashMap<String, Player>();

public PlayerDaoo() {
		Player player1 = new Player();
		player1.setId("1");  
		player1.setAge(20);
		player1.setName("raj");
		
		Player player2 = new Player();
		player2.setId("2");
		player2.setAge(21);
		player2.setName("ram");
		
		PlayersMap.put("1", player1); 
		PlayersMap.put("2", player2);
}

public List<Player> getAllPlayers() {

	List<Player> playerList = new ArrayList<Player>(PlayersMap.values());
	return playerList;
}

public Player getPlayerForId(String id) {
	Player player = PlayersMap.get(id); //map's get method
	return player;
}

public Player createPlayer(Player player) {
	PlayersMap.put(player.getId(), player); //add to the map
	return PlayersMap.get(player.getId());//confirm from the map
}

public Player updatePlayer(Player player) {
	Player existingPlayer= PlayersMap.get(player.getId());
	if (existingPlayer != null) { //update 
		existingPlayer.setName(player.getName());
		existingPlayer.setAge(player.getAge());
	} else {
		PlayersMap.put(player.getId(), player); // save
	}
	return PlayersMap.get(player.getId()); //confirm the map updates
}

public Player deletePlayer(String id) {
	Player playerResponse = PlayersMap.remove(id);
	return playerResponse;
}

}


