package com.java.rest.resource;


import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.java.model.Player;
import com.java.service.PlayerService;


@Path("/playerInfo")
public class PlayerResource {


	PlayerService playerService = new PlayerService();

	// CRUD -- CREATE operation
	@POST
	@Produces(MediaType.TEXT_XML)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Player createPlayer(@FormParam("id") String id,@FormParam("name") String name,@FormParam("age") int age) {
		System.out.println("createPlayer() rest api");
		Player player = new Player();
		player.setId(id);
		player.setName(name);
		player.setAge(age);
		Player playerResponse = playerService.createPlayer(player);
		return playerResponse;
	}

	// CRUD -- READ operation
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Player> getAllPlayers() {
		System.out.println("getAllPlyers() rest api");
		List<Player> playerList = playerService.getAllPlayers();
		return playerList;
	}


	// CRUD -- UPDATE operation
	@PUT
	@Produces(MediaType.TEXT_XML)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Player updatePlayer(@FormParam("id") String id,@FormParam("name") String name,@FormParam("age") int age) {
		System.out.println("updatePlayer() rest api");
		Player player = playerService.getPlayerForId(id);
		player.setName(name);
		player.setAge(age);
		Player playerResponse = playerService.updatePlayer(player);
		return playerResponse;
	}

	// CRUD -- DELETE operation
	@DELETE
	@Produces(MediaType.TEXT_XML)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Player deletePlayer(@FormParam("id") String id) {
		System.out.println("deletePlayer() rest api");
		Player playerResponse = playerService.deletePlayer(id);
		return playerResponse;
	}
}


