package com.java.service;




import java.util.List;

import com.java.dao.PlayerDaoo;
import com.java.model.Player;


public class PlayerService {	                    
	PlayerDaoo playerDaoo = new PlayerDaoo();

	public List<Player> getAllPlayers() {
		List<Player> playerList = playerDaoo.getAllPlayers();
		return playerList;
	}

	public Player getPlayerForId(String id) {
		//u can write business logic code
		//some business logic can be written here
		Player Player = playerDaoo.getPlayerForId(id);
		//post activity after dao.
		return Player;
	} 

	public Player createPlayer(Player player) {
		Player playerResponse = playerDaoo.createPlayer(player);
		return playerResponse;
	}

	public Player updatePlayer(Player player) {
		Player playerResponse = playerDaoo.updatePlayer(player);
		return playerResponse;
	}

	public Player deletePlayer(String id) {
		Player playerResponse = playerDaoo.deletePlayer(id);
		return playerResponse;
	}

}
