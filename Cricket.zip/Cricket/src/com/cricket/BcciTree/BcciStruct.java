package com.cricket.BcciTree;

public class BcciStruct  implements Comparable<BcciStruct>{
	String name;
	String designation;
	int salary;
	

	@Override
	public int compareTo(BcciStruct a) {
		System.out.println("compareTo is invoked...comparing "+designation+" with "+a.designation);
		return designation.compareTo(a.designation);
	}

	public BcciStruct(String name, String designation, int salary) {
		super();
		this.name = name;
		this.designation = designation;
		this.salary = salary;
		
	}

	@Override
	public String toString() {
		return "BcciStruct [name=" + name + ", designation=" + designation + ", salary=" + salary + "]";
	}

	
	}

/*
 *                         President
 *                            |
 *                            |
 *              CEO ----------------------------The Selection Committee head
 *               |                                            |
 *Administration---operational manager  New men's selection-----women's selection
 *             
 *                                             
 *                                  
 *            
 *                                   
 *                                            
 *                             
 *            
*/


