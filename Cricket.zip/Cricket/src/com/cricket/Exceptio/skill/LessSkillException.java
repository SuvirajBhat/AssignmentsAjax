package com.cricket.Exceptio.skill;

public class LessSkillException extends Exception {
	public LessSkillException(String str){
		super(str);
	}}