package com.cricket.U14;


public class U14{
	
	
	public U14() {}


	public void playU14() {
		
System.out.println("player is performing well..");
System.out.println("Some good techniques..");
		
	}

	
	}

	


	




