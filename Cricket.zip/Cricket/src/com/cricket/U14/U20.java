package com.cricket.U14;

import com.cricket.Exceptio.skill.LessSkillException;

//import com.cricket.lessSkill.lessSkill;

//import com.cricket.ageexception.AgeException;

public class U20 extends U14 {
	int skillPoint;

	public U20(int skillPoint) {

		this.skillPoint = skillPoint;

	}
	
public int getSkillPoint() {
		return skillPoint;
	}

public void U19(int skillPoint) throws LessSkillException {
	System.out.println("-------------");
		System.out.println("Selectors have eyes on him");
		super.playU14();
		System.out.println("His skill point is " + skillPoint);
		if (skillPoint < 5) {
		throw new LessSkillException("Diffcult to get into the team lets and check the average");
			}
else {
	System.out.println("welcome");
//		
//		
		}
}
}
	


