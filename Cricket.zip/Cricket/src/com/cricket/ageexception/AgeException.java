package com.cricket.ageexception;

public class AgeException extends Exception {
	public AgeException(String str){
		super(str);
	}

}
