package com.cricket.batsman;

import com.cricket.U14.U20;

public class Batsman {
	
	
	public void BatAvg(int average) {
		U20 u20=new U20(4);
		
		
     if (average<35) {
				 throw new ArithmeticException("Batsman is rejected bcs avg is less than 35");
			}
		
	else{
		System.out.println("-----------------");
			System.out.println("U have good  average of "+average+"but less skil point of "+u20.getSkillPoint());
		}
     }

	
}
