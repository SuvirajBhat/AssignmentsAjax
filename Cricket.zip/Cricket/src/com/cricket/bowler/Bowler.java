package com.cricket.bowler;

public class Bowler {
	int speed;
	String name;
	static String bowlType="Seamer";
	public Bowler(String name,int speed) {
		super();
		this.name=name;
		this.speed = speed;
		
		
	}
	public void displayBInfo() {
		System.out.println(name+" his speed is "+speed+"kmph and he is a "+bowlType);
	}

}
