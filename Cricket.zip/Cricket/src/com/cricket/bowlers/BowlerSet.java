package com.cricket.bowlers;

public class BowlerSet {
	String name;
	String role;
	
	public BowlerSet(String name, String role) {
		super();
		this.name = name;
		this.role = role;
		
	}
	@Override
	public String toString() {
		return "Players [name=" + name + ", role=" + role + "]";
	}
	
	
	

}
