package com.cricket.coach;

 public abstract class Stratergist {
   public abstract void plan();
}
