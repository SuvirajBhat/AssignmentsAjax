package com.cricket.players;

public class Players {
	String name;
	String role;
	int position;
	public Players(String name, String role, int position) {
		super();
		this.name = name;
		this.role = role;
		this.position = position;
	}
	@Override
	public String toString() {
		return "Players [name=" + name + ", role=" + role + ", position=" + position + "]";
	}
	
	
	

}
