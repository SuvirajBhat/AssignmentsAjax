package com.cricket.strikerate;

public interface StrikeRate {
void strike();
static void rate(int runs,int balls) {
	System.out.println("the strike rate is "+(runs/balls)*100);
}
public class BatStrikeRate implements StrikeRate{
	public void strike() {
		System.out.println("getting strikerate");
	}
}
}
