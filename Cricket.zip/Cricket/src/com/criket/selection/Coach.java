package com.criket.selection;

import com.cricket.coach.Stratergist;

public class Coach extends Stratergist {

	@Override
	public void plan() {
		
			System.out.println("planning and coaching well");
		}

	}


