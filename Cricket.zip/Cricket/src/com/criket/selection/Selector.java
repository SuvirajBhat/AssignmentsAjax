package com.criket.selection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.TreeSet;

import com.cricket.BcciTree.BcciStruct;
import com.cricket.Exceptio.skill.LessSkillException;
import com.cricket.U14.U14;
import com.cricket.U14.U20;
import com.cricket.batsman.Batsman;
import com.cricket.bowler.Bowler;
import com.cricket.bowlers.BowlerSet;
import com.cricket.coach.Stratergist;
import com.cricket.players.Players;
import com.cricket.strikerate.StrikeRate;

public class Selector {
	public static void main(String[] args) {
		U14 u1=new U14();
		u1.playU14();
		 
		U20 u2=new U20(4);
	    try{
	    	u2.U19(4);
	    }
	    catch(LessSkillException ex) {
	    	System.out.println("This batsman is having less skillpoint");
	    }
	    finally {
	    	System.out.println("go ahead with the average");
	    }
	    Batsman batter = new Batsman();
		batter.BatAvg(50);
		System.out.println("lets calculate strikerate");
        //StrikeRate sr=new BatStrikeRate();
		//sr.strike();
		StrikeRate.rate(200, 50);
		System.out.println("--------------");
		System.out.println("lets get bowler's info");
		Bowler b1=new Bowler("Bhuvi",140);
		b1.displayBInfo();
		Bowler b2=new Bowler("Bumrah",145);
		b2.displayBInfo();
		System.out.println("------------------");
		Stratergist c1=new Coach();
		c1.plan();
		ArrayList<Players> teamPlayers=new ArrayList<Players>();
		System.out.println("-----------------");
		System.out.println("Player's are ready"); //container is ready
		Players p1= new Players("Rohit","Right Handed opening Batsman",1);
		Players p2= new Players("Dhawan","Left Handed opening Batsman",2);
		Players p3= new Players("Virat","Right Handed Batsman",3);
		Players p4= new Players("S Yadav","Right Handed  Batsman",4);
		Players p5= new Players("Pant","Left Handed Batsman",5);
		teamPlayers.add(p1);
		teamPlayers.add(p2);
		teamPlayers.add(p3);
		teamPlayers.add(p4);
		teamPlayers.add(p5);
		System.out.println("Batting order is added");
		Iterator<Players>playerIterator=teamPlayers.iterator();
		while(playerIterator.hasNext()) {
			Players play=playerIterator.next();
			System.out.println("the batting order is "+play);
		}
		System.out.println("--------------------");
		LinkedList<BowlerSet> Bowlers=new LinkedList<BowlerSet>();
		System.out.println("Bowler's Ready");
		BowlerSet bs1=new BowlerSet("Bumrah","Seamer");
		BowlerSet bs2=new BowlerSet("Jaddu","Seamer");
		BowlerSet bs3=new BowlerSet("Yuzi","Spinner");
		BowlerSet bs4=new BowlerSet("Ashwin","Spinner");
		Bowlers.add(bs1);
		Bowlers.add(bs2);
		Bowlers.add(bs3);
		Bowlers.add(bs4);
		Collections.swap(Bowlers, 2, 0);
		Iterator<BowlerSet>BowlerIterator=Bowlers.iterator();
		while(BowlerIterator.hasNext()) {
			BowlerSet bowl=BowlerIterator.next();
			System.out.println("the bowling sequence is "+bowl);
		}
		System.out.println("----------------------");
		
		System.out.println("----------------------");
		System.out.println("lets see how bcci looks");
        TreeSet<BcciStruct> structure=new TreeSet<BcciStruct>();
        System.out.println("members are...");
        BcciStruct member1=new BcciStruct("Saurav","President",50000000);
        BcciStruct member2=new BcciStruct("RAHUL JOHRI","CEO",30000000);
        BcciStruct member3=new BcciStruct("Sharath Sridharan","The Selection Committee head",9000000);
        BcciStruct member4=new BcciStruct("Sunil Joshi","New men's selection",6000000);
        BcciStruct member5=new BcciStruct("Neetu David","women's selection",5000000);
        BcciStruct member6=new BcciStruct("Abhidya","operational manager",3000000);
        BcciStruct member7=new BcciStruct("David","Administration",2000000);
        System.out.println("adding by designation");
        structure.add(member1);
        System.out.println("------------");
        structure.add(member2);
        System.out.println("------------");
        structure.add(member3);
        System.out.println("------------");
        structure.add(member4);
        System.out.println("------------");
        structure.add(member5);
        System.out.println("------------");
        structure.add(member6);
        System.out.println("------------");
        structure.add(member7);
        System.out.println("------------");
        Iterator<BcciStruct> iterator=structure.iterator();
        while(iterator.hasNext()) {
        	BcciStruct member=iterator.next();
        	System.out.println("members: "+member);
        }
	
	}
	
}














//class IndTeam {
//
//}
//
//class U19 extends IndTeam {  //is-A
//	Coaches coach=new Coaches();//has-A
//	Analyst a= new Analyst();
//
//	Eplayer teamSelection(Batsman Batsman, Bowler Bowler, AllRounder Allrounder) { //uses a
//		System.out.println("Team selection");
//		Eplayer eplayer = new Eplayer();
//		return eplayer;
//
//	}
//
//	public void playU14() {
//		// TODO Auto-generated method stub
//		
//	}
//
//	public void u19Selection() {
//		// TODO Auto-generated method stub
//		
//	}
//}
//
//
//class FitPlayer {}
//
//
//
//class Bowler {}
//
//class AllRounder {}
//class Coaches{}
//class Analyst{}
//
//class Eplayer extends FitPlayer {
//	String result = "Selected";
//
//	@Override
//	public String toString() {
//		return "Eplayer [result=" + result + "]";
//	}
//
//}
