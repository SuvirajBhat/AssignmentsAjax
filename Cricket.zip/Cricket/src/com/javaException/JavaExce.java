package com.javaException;

import java.util.InputMismatchException;
import java.util.Scanner;

public class JavaExce {
	public static void main(String[] args) {
		int num = 0,den=0;
		MyCalci cal=new MyCalci();
		try {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the num: ");
	    num=sc.nextInt();
		System.out.println("enter the deno.. ");
		den=sc.nextInt();
		}
		catch(InputMismatchException ime) {
			System.out.println("expecting the Integer");
		}
		
		cal.devide(num, den);
	}

}
