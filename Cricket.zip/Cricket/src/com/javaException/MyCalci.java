package com.javaException;

class MyCalci{
	void devide(int num,int den) {
		try {
		System.out.println("Start deviding");
		int result=num/den;
		System.out.println("the numerator is "+num);
		System.out.println("the denominator is "+den);
		System.out.println("the result is "+result);
		}
		catch(ArithmeticException e) {
			System.out.println("Wrong denom  "+den);
		}
	}
}
