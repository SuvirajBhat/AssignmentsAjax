package com.java;

import java.util.ArrayList;


import javax.ws.rs.PathParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.glassfish.jersey.process.internal.RequestScoped;
//http://localhost:8080/DynamicCric/rest/cricket/myAvg
@Path("/cricket")

public class Cricket {

	static ArrayList<Average> avgPlayers=new ArrayList<Average>();
	static {
	System.out.println("Player's are ready"); //container is ready
	Average p1= new Average();
	p1.setId(1);
	p1.setMatches(20);
	p1.setRuns(1000);
	
	Average p2= new Average();
	p2.setId(2);
	p2.setMatches(30);
	p2.setRuns(2000);
	
	
	Average p3= new Average();
	p3.setId(3);
	p3.setMatches(300);
	p3.setRuns(10000);
	
	Average p4= new Average();
	p4.setId(4);
	p4.setMatches(30);
	p4.setRuns(5000);
  
	
	avgPlayers.add(p1);
	avgPlayers.add(p2);
	avgPlayers.add(p3);
	avgPlayers.add(p4);
	

}
	//http://localhost:8080/DynamicCric/rest/cricket/myAvg
@GET
@Path("/myAvg")
@Produces(MediaType.APPLICATION_JSON)
public Average players(){
	System.out.println("finding...");
	Average average =new Average();
	average.setMatches(20);
	average.setRuns(1000);
    return average;
	
	
}
//http://localhost:8080/DynamicCric/rest/cricket/getAvges
@GET
@Path("/getAvges")
@Produces(MediaType.APPLICATION_JSON)
public ArrayList<Average>getAllAvg(){
	System.out.println("get all averages"); 
	return avgPlayers;
}
//http://localhost:8080/DynamicCric/rest/cricket/getAvg/1

@GET
@Path("/getAvg/{aid}")
@Produces(MediaType.APPLICATION_JSON)
public Average getAvg(@PathParam("aid") int tempAid) {
	System.out.println("getAverage..."+tempAid);
	Average tempAverage = null;
	for(Average theAverage  : avgPlayers) {
		if(theAverage.getId() == tempAid) {
			tempAverage = theAverage;
			break;
}
}
	return tempAverage;
}
//http://localhost:8080/DynamicCric/rest/conversion/updateAvg/1
@PUT 
@Path("/updateAvg")	
@Produces(MediaType.APPLICATION_JSON)
public void modifyAvg(Average avgToModify) {
	System.out.println("modifyAverage...."+avgToModify);		
	for(int i=0;i<avgPlayers.size();i++) {
		Average average = avgPlayers.get(i);
		
		System.out.println("currency to modify is "+avgToModify.getId());
		
		if(average.getId() == avgToModify.getId()) {
			average  = avgPlayers.get(i);
			avgPlayers.remove(average);
			avgPlayers.add(i, avgToModify);
			avgPlayers.add(avgToModify);
			System.out.println("average modified...");
			break;
		}
	}
}
//http://localhost:8080/DynamicCric/rest/conversion/addAvg
@POST 
@Path("/addAvg")	
@Produces(MediaType.APPLICATION_JSON)
public Response addAvg(Average newAvg) {
	System.out.println("add new average...."+newAvg);		
	avgPlayers.add(newAvg);
	return Response.status(201).build();
}

}

