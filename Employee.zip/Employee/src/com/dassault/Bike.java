package com.dassault;

public class Bike extends Vehicle {
	private boolean handle=true;
	


public Bike(String name,String color,int wheels,String engine,boolean handle) {
	super(name,color,wheels,engine);
	this.handle=handle;
	
}



public boolean getHandle() {
	return this.handle;
}



public void setHandle(boolean handle) {
	this.handle = handle;
}
public String getInfo() {
	return "This isa bike";
}
}
