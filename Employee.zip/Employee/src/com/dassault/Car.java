package com.dassault;

public class Car extends Vehicle{
	private boolean powerSteering=false;
	private boolean ledScreen=true;
	
	public Car(String name,String color,int wheels,String engine,boolean powerSteering, boolean ledScreen) {
		super(name,color,wheels,engine);
		this.ledScreen=ledScreen;
		this.powerSteering=powerSteering;
	}
	public String getName() {
		return "Name of your  vehicle is "+super.getName();//to access from the parent function
	}
	public boolean isPowerSteering() {
		return powerSteering;
	}

	public void setPowerSteering(boolean powerSteering) {
		this.powerSteering = powerSteering;
	}

	public boolean isLedScreen() {
		return ledScreen;
	}

	public void setLedScreen(boolean ledScreen) {
		this.ledScreen = ledScreen;
	}
	
	public String getInfo() {
		return "This isa car ";
	}
}
