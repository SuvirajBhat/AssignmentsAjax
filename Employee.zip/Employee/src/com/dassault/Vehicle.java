package com.dassault;
//import java.util.Scanner;

public class Vehicle{      //set as parent class
	private String name="";
	private String color="";
	private int wheels;
	private String engine="";
	public static int count=0;

	public Vehicle() {
		count++;
	}
 public Vehicle(String name,String color,int wheels,String engine) {
		this.name=name;
		this.color=color;
		this.wheels=wheels;
		this.engine=engine;
		count++;
//		System.out.println("enter the cc value: ");
//		Scanner sc=new Scanner(System.in);
//		engine=sc.nextLine();
	}
 public void setName(String name) {
	 this.name=name;
 }
 public void setColor(String color) {
	 this.color=color;
 }
 public void setWheel(int wheels) {
	 this.wheels=wheels;
 }
private String getEngine() {
	 
	
	return this.engine;
}
public void setEngine(String engine) {
	this.engine = engine;
}
public String getName() {
	return this.name;
}
public String getColor() {
	return this.color;
}
public int getWheels() {
	return this.wheels;
}

public int getSpeed() {
	
	String a=getEngine();
	
	if(a=="80") {
		return 90;
	}
	else {
		return 120;
	}
}
public static String getVehicle() {
	return "You have set the neame and color of vehicle";
}
public String getInfo() {
	return "This isa vehicle";
}
}
