package com.dassault;

public class main {
public static void main(String[] args) {
	Vehicle v1=new Vehicle(); 
	v1.setName("Maruti");
	//System.out.println(v1.name);
	v1.setWheel(6);
	//System.out.println(v1.wheels);
	Vehicle v2=new Vehicle("orange","black",3,"800"); 
	v2.setColor("orange");
	v2.setName("omini");
	Car c1=new Car("orange","black",3,"800",true,false);
	System.out.println(c1.isPowerSteering());
	System.out.println(c1.getName());
	
	System.out.println(v2.getName());
	System.out.println(v2.getColor());
	System.out.println(v2.getSpeed());
	//System.out.println(v1.count);
	//System.out.println(v2.count);
	Vehicle.getVehicle();//it doesn't depend on construction of object ie v1 and v2
	System.out.println(c1.getInfo());
	Vehicle v3=new Car("orange","black",3,"800",true,false);
	System.out.println(v3.getInfo());
	
}
}
