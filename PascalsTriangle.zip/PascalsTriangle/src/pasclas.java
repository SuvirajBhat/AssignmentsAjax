import java.util.Scanner;
public class pasclas {
public static void main(String[] args) {
	int n,i,j,k,s;
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter the number of lines: ");
	n=sc.nextInt();
    
		
	s=n;
	int number=1;
	for(i=n;i>=0;i--) {
		
		
		for(k=s;k>=1;k--) {      // bcs always n-i number of spaces
			System.out.print(" ");//giving left spaces
		}
		number=1;
		for(j=0;j<=i;j++) 
		{
	
			System.out.print(number+" ");
			number=number*(i-j)/(j+1);
		}
		s++;
			
		
		
		System.out.println();
	}
	
	
	
sc.close();

}
}

