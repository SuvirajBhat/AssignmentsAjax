package com.company;


public class Main {

    public static void main(String[] args) {
	// write your code here
        Studentprofile stud1=new Studentprofile("Harish","Bhat",112,7.7,2022);
        Studentprofile stud2=new Studentprofile("Haris","Bht",192,9.7,2022);
        System.out.println(stud1.firstname);
        System.out.println(stud2.graduationYear);
        System.out.println(stud1.expectedgrad(stud1.graduationYear));
    }
}
 class Studentprofile{
    String firstname;
    String lastname;
    int studentID;
    double gpa;
    int graduationYear;

    public Studentprofile(String firstname,String lastname,int studentID,double gpa,int graduationYear){
        this.firstname=firstname;
        this.lastname=lastname;
        this.studentID=studentID;
        this.gpa=gpa;
        this.graduationYear=graduationYear;
    }

    public int expectedgrad(int graduationYear){
      this.graduationYear =this.graduationYear+1;
      return graduationYear;
        }

}
